/*
	C Project
	Address Book

	MAIN CONSOLE PROGRAM

*/


int main(void)
{

}
